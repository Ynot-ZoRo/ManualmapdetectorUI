using System.Windows;

namespace ManualMapDetectorWPF
{
    public partial class App : Application { }
}
